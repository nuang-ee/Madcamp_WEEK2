package com.example.myfirstapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.provider.ContactsContract
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * A simple [Fragment] subclass.
 */
class SecondFragment : Fragment() {

    private var recyclerView: RecyclerView? = null
    private var customAdapter: CustomAdapter? = null
    private var ImageModelArrayList: ArrayList<ImageModel>? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_second, container, false)
        recyclerView = view.findViewById(R.id.recyclerView) as RecyclerView

        ImageModelArrayList = ArrayList()

        //여기부터 해서 이미지 가져오는 부분
        val image = getActivity()?.getContentResolver()?.query(

        )
        while (image!!.moveToNext()) {
            val name =
                phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME))
            val phoneNumber =
                phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))
            //val mail = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Email.CONTENT_URI))

            val contactModel = ContactModel()
            contactModel.setNames(name)
            contactModel.setNumbers(phoneNumber)
            contactModelArrayList!!.add(contactModel)
            Log.d("name>>", name + "  " + phoneNumber)
        }
        phones.close()

        //customAdapter가 contactModel 최적화?라서 수정이나 이와 같은 역할의 클래스를 만들어주면 될 듯
        customAdapter = getContext()?.let { CustomAdapter(it, ImageModelArrayList!!) }
        recyclerView!!.adapter = customAdapter

        val lm = LinearLayoutManager(getContext())
        recyclerView!!.layoutManager = lm
        recyclerView!!.setHasFixedSize(true)

        return view
    }
}
